import React, { useState, useEffect } from "react";

export default function AdminPanel() {
  const [form, setForm] = useState({ id: "", title: "", description: "", price: "", image: null });
  const [products, setProducts] = useState([]);

  // Fetch products
  useEffect(() => {
    async function fetchProducts() {
      try {
        const res = await fetch("http://localhost:5000/product/api");
        const data = await res.json();
        setProducts(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error(err);
      }
    }
    fetchProducts();
  }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const handleFileChange = (e) => setForm({ ...form, image: e.target.files[0] });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("id", form.id); // ID add kiya
    formData.append("title", form.title);
    formData.append("description", form.description);
    formData.append("price", form.price);
    formData.append("image", form.image);

    try {
      await fetch("http://localhost:5000/product/admin", {
        method: "POST",
        body: formData
      });
      setForm({ id: "", title: "", description: "", price: "", image: null });

      // Refresh products
      const res = await fetch("http://localhost:5000/product/api");
      const data = await res.json();
      setProducts(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h2 className="text-3xl font-bold mb-6 text-center text-purple-600">Admin Panel</h2>

      <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-xl p-6 flex flex-col gap-4" encType="multipart/form-data">
        <input name="id" type="number" placeholder="ID" value={form.id} onChange={handleChange} required />
        <input name="title" placeholder="Title" value={form.title} onChange={handleChange} required />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Price" value={form.price} onChange={handleChange} required />
        <input type="file" accept="image/*" onChange={handleFileChange} required />
        <button type="submit" className="bg-purple-600 text-white p-2 rounded">Add Product</button>
      </form>

      <h3 className="mt-6 text-xl font-bold">Added Products</h3>
     <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
  {products.map((p) => (
    <div key={p._id} className="border p-2 rounded shadow">
      <img
        src={`http://localhost:5000${p.image}`} // <-- ye important
        alt={p.title}
        className="h-48 w-full object-contain"
      />
      <p className="font-bold">{p.title}</p>
      <p>₹{p.price}</p>
    </div>
  ))}
</div>

    </div>
  );
}
