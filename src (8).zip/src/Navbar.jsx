import React, { useState } from "react";
import { ShoppingCartIcon, Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar({ cart = [] }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const navigate = useNavigate();

  const handleSearchChange = async (e) => {
    const query = e.target.value;
    setSearchTerm(query);

    if (query.length > 1) {
      try {
        const res = await fetch(`http://localhost:5000/product/search/${encodeURIComponent(query)}`);
        const data = await res.json();
        setSuggestions(data);
      } catch (err) {
        console.error(err);
      }
    } else {
      setSuggestions([]);
    }
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 text-2xl font-bold text-indigo-600">ShopEase</div>

          <div className="hidden md:block flex-1 px-4 relative">
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={handleSearchChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-indigo-400 outline-none"
            />
            {suggestions.length > 0 && (
              <div className="absolute bg-white border w-full mt-1 rounded shadow-lg z-50 max-h-80 overflow-y-auto">
                {suggestions.map((item) => (
                  <div
                    key={item.id}
                    className="p-2 hover:bg-indigo-100 cursor-pointer flex items-center gap-2"
                    onClick={() => navigate(`/product/${item.id}`)}
                  >
                    <img src={item.image} alt={item.title} className="w-12 h-12 object-contain rounded" />
                    <div className="flex flex-col">
                      <span className="font-semibold text-gray-700">{item.title}</span>
                      <span className="text-sm text-gray-500">{item.description.substring(0, 30)}...</span>
                      <span className="text-green-600 font-semibold">₹{item.price}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-700 hover:text-indigo-600">Shop</Link>
            <Link to="/category" className="text-gray-700 hover:text-indigo-600">Categories</Link>
            <Link to="/offer" className="text-gray-700 hover:text-indigo-600">Offers</Link>
            <Link to="" className="text-gray-700 hover:text-indigo-600">Contact</Link>
            <Link to="/orders" className="text-gray-700 hover:text-indigo-600">Order</Link>

            <div className="relative cursor-pointer" onClick={() => navigate("/Cart")}>
              <ShoppingCartIcon className="h-6 w-6 text-gray-700" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {cart.length}
                </span>
              )}
            </div>

            {/* Login & Signup (Shared route with mode state) */}
            <button
              onClick={() => navigate("/register", { state: { mode: "login" } })}
              className="px-4 py-1 border border-indigo-600 text-indigo-600 rounded-full hover:bg-indigo-600 hover:text-white transition"
            >
              Login
            </button>
            <button
              onClick={() => navigate("/register", { state: { mode: "signup" } })}
              className="px-4 py-1 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition"
            >
              Signup
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <XMarkIcon className="h-6 w-6 text-gray-700" /> : <Bars3Icon className="h-6 w-6 text-gray-700" />}
            </button>
          </div>
        </div>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-2 space-y-2">
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Shop</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Categories</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Offers</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Contact</a>

            <div className="flex items-center space-x-2">
              <ShoppingCartIcon className="h-6 w-6 text-gray-700" />
              <span className="text-gray-700">Cart ({cart.length})</span>
            </div>

            <button
              onClick={() => navigate("/register", { state: { mode: "login" } })}
              className="w-full px-4 py-2 border border-indigo-600 text-indigo-600 rounded-full hover:bg-indigo-600 hover:text-white transition"
            >
              Login
            </button>
            <button
              onClick={() => navigate("/register", { state: { mode: "signup" } })}
              className="w-full px-4 py-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition"
            >
              Signup
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
