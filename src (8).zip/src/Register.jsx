import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";

function Register({ setUser, redirectPath = "/" }) {
  const location = useLocation();
  const navigate = useNavigate();

  const [isLogin, setIsLogin] = useState(true);
  const [isForgot, setIsForgot] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    if (location.state?.mode === "login") {
      setIsLogin(true);
      setIsForgot(false);
    } else if (location.state?.mode === "signup") {
      setIsLogin(false);
      setIsForgot(false);
    }
  }, [location.state]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (isForgot) {
        const res = await axios.post("http://localhost:5000/forgot", { email });
        alert(res.data.message || "Password reset link sent!");
        setIsForgot(false);
      } else if (isLogin) {
        const res = await axios.post("http://localhost:5000/login", { email, password });
        if (res.data.success) {
          alert(res.data.message);
          localStorage.setItem("token", res.data.token); // JWT save
          setUser(res.data.user); // Set logged-in user in parent
          navigate(redirectPath); // redirect after login
        } else {
          alert(res.data.message);
        }
      } else {
        const res = await axios.post("http://localhost:5000/register", { name, email, password });
        alert(res.data.message);
        localStorage.setItem("token", res.data.token); // JWT save
        setUser(res.data.user); // Set logged-in user
        setIsLogin(true);
        navigate(redirectPath); // redirect after register
      }
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Something went wrong!");
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gradient-to-br from-blue-100 to-purple-200">
      <div className="bg-white shadow-lg rounded-lg p-8 w-full max-w-sm">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-700">
          {isForgot ? "Forgot Password" : isLogin ? "Login" : "Register"}
        </h2>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {!isLogin && !isForgot && (
            <input
              className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              type="text"
              placeholder="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          )}

          <input
            className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
            type="email"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          {!isForgot && (
            <input
              className="border p-3 rounded focus:outline-none focus:ring-2 focus:ring-blue-400"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          )}

          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white p-3 rounded font-semibold transition"
          >
            {isForgot ? "Send Reset Link" : isLogin ? "Login" : "Register"}
          </button>
        </form>

        {isLogin && !isForgot && (
          <p
            onClick={() => setIsForgot(true)}
            className="mt-3 text-sm text-blue-500 cursor-pointer hover:underline text-center"
          >
            Forgot Password?
          </p>
        )}

        <p className="mt-6 text-center text-gray-600">
          {isForgot
            ? "Remember your password?"
            : isLogin
            ? "Don't have an account?"
            : "Already have an account?"}{" "}
          <span
            onClick={() => {
              setIsForgot(false);
              setIsLogin(isForgot ? true : !isLogin);
            }}
            className="text-blue-500 cursor-pointer hover:underline"
          >
            {isForgot
              ? "Login here"
              : isLogin
              ? "Register here"
              : "Login here"}
          </span>
        </p>
      </div>
    </div>
  );
}

export default Register;
