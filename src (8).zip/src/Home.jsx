import React, { useEffect, useState } from "react";

import { Link } from "react-router-dom";
import Footer from "./Footer";
import Category from "./Category";

function Home({ cart, setCart }) {
  const [products, setProducts] = useState([]);

  // Fetch Products
  useEffect(() => {
    fetch("http://localhost:5000/product/api")
      .then((res) => res.json())
      .then((data) => setProducts(Array.isArray(data) ? data : []))
      .catch((err) => console.error("Error fetching products:", err));
  }, []);

  return (
    <>
     


      {/* Category Section */}
      <Category />

      {/* Featured Products */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-extrabold mb-10 text-center bg-gradient-to-r from-blue-600 via-purple-500 to-pink-500 bg-clip-text text-transparent drop-shadow-lg">
          Featured Products
        </h1>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <Link
              key={product._id || product.id}
              to={`/product/${product._id || product.id}`}
              className="group relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100 overflow-hidden"
            >
              {/* Product Image */}
              <div className="relative w-full h-64 flex justify-center items-center bg-gray-50 overflow-hidden">
                <img
                  src={`http://localhost:5000${product.image}`}
                  alt={product.title}
                  className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute top-3 left-3 bg-gradient-to-r from-pink-500 to-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                  New
                </span>
              </div>

              {/* Product Info */}
              <div className="p-5 flex flex-col justify-between h-40">
                <h2 className="font-semibold text-lg text-gray-800 mb-2 line-clamp-2 group-hover:text-purple-600 transition-colors duration-300">
                  {product.title}
                </h2>
                <div className="flex items-center justify-between">
                  <p className="text-blue-600 font-extrabold text-xl">
                    ₹{product.price}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <Footer />
    </>
  );
}

export default Home;
