import React, { useState, useEffect } from "react";

export default function Category() {
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedSubcategory, setSelectedSubcategory] = useState(null);

  // Fetch all categories
  useEffect(() => {
    fetch("http://localhost:5000/product/categories")  // Ensure the API endpoint is correct
      .then((res) => res.json())
      .then((data) => {
        if (data.categories) {
          setCategories(data.categories); // Set categories from the response
        } else {
          console.error("Categories data not found in response");
        }
      })
      .catch((err) => console.error("Error fetching categories:", err));
  }, []);  // Empty dependency array means this effect will run once after the first render

  // Handle category click
  const handleCategoryClick = (cat) => {
    setSelectedCategory(cat);
    setSelectedSubcategory(null);
    setProducts([]);

    // Fetch subcategories for the selected category
    fetch(`http://localhost:5000/categories/${cat._id}`)  // Ensure the category object has an _id field
      .then((res) => res.json())
      .then((data) => setSubcategories(data))  // Assuming the response contains the subcategories
      .catch((err) => console.error("Error fetching subcategories:", err));
  };

  // Handle subcategory click
  const handleSubcategoryClick = (sub) => {
    setSelectedSubcategory(sub);

    // Fetch products for the selected category & subcategory
    fetch(`http://localhost:5000/api/products/${selectedCategory._id}/${sub._id}`)  // Adjust API to accept category and subcategory IDs
      .then((res) => res.json())
      .then((data) => setProducts(data))
      .catch((err) => console.error("Error fetching products:", err));
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">Categories</h2>
      <div className="flex gap-4 flex-wrap">
        {categories.map((cat, idx) => (
          <button
            key={idx}
            onClick={() => handleCategoryClick(cat)}
            className={`px-4 py-2 border rounded ${selectedCategory?._id === cat._id ? "bg-blue-500 text-white" : "bg-gray-100"}`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {subcategories.length > 0 && (
        <div className="mt-4">
          <h3 className="text-lg font-semibold">Subcategories of {selectedCategory?.name}</h3>
          <div className="flex gap-3 flex-wrap mt-2">
            {subcategories.map((sub, idx) => (
              <button
                key={idx}
                onClick={() => handleSubcategoryClick(sub)}
                className={`px-3 py-1 border rounded ${selectedSubcategory?._id === sub._id ? "bg-green-400 text-white" : "bg-green-200"}`}
              >
                {sub.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {products.length > 0 && (
        <div className="mt-4 grid grid-cols-3 gap-4">
          {products.map((p) => (
            <div key={p.id} className="border p-2 rounded">
              <img src={p.image} alt={p.title} className="w-full h-40 object-cover" />
              <h3 className="font-semibold mt-2">{p.title}</h3>
              <p>₹{p.price}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
