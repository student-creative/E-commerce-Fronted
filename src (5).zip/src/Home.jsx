import { useEffect, useState } from "react";
import React from "react";
import Navbar from "./Navbar";
import { Link } from "react-router-dom";
import Footer from "./Footer";

function Home({ cart, setCart }) {
  const [products, setProducts] = useState([]);

  // Fetch Products
  useEffect(() => {
    fetch("http://localhost:5000/product/api")
      .then((res) => res.json())
      .then((data) => setProducts(data))
      .catch((err) => console.error("Error fetching products:", err));
  }, []);

  return (
    <>
      <Navbar cart={cart} />

      <div className="max-w-7xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">
          Featured Products
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Link
              key={product.id}
              to={`/product/${product.id}`}
              className="group bg-white rounded-lg shadow-md hover:shadow-xl transition transform hover:-translate-y-1 flex flex-col overflow-hidden"
            >
              {/* Product Image */}
              <div className="h-56 w-full overflow-hidden">
                <img
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>

              {/* Product Info */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <h2 className="font-semibold text-lg text-gray-800 mb-2 line-clamp-2">
                  {product.title}
                </h2>
                <p className="text-blue-600 font-bold text-xl mt-auto">
                  ₹{product.price}
                </p>
              </div>
            </Link>
          ))}
        </div>
       
      </div>
       <Footer />
    </>
  );
}

export default Home;
