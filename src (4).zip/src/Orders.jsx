import React, { useContext, useEffect } from "react";
import { OrderContext } from "./OrderContext";

function Orders() {
  const { orders, setOrders } = useContext(OrderContext);
  const userId = "123"; // 👈 Login ke baad yaha se aana chahiye

useEffect(() => {
  fetch(`http://localhost:5000/order/${userId}`)
    .then(res => res.json())
    .then(data => {
      setOrders(data.orders); // ✅ yaha array milega
    })
    .catch(err => console.error("Fetch error:", err));
}, [userId]);

  return (
  <div className="p-6">
  <h1 className="text-2xl font-bold">My Orders</h1>
  {orders.length === 0 ? (
    <p>No orders placed yet.</p>
  ) : (
    <div className="space-y-4 mt-4">
      {orders.map((order, idx) => (
        <div key={idx} className="border p-4 rounded shadow">
          <p><b>Order ID:</b> {order._id}</p>
          <p><b>Status:</b> {order.status}</p>
          <p><b>Total:</b> ₹{order.totalAmount}</p>
          <p><b>Payment:</b> {order.paymentMethod || "N/A"}</p>
          <p><b>Date:</b> {new Date(order.createdAt).toLocaleString()}</p>

          {/* ✅ Shipping Details */}
          <div className="mt-4 p-3 bg-gray-50 rounded">
            <h3 className="font-semibold">Shipping Details</h3>
            <p><b>Name:</b> {order.shippingDetails.fullName}</p>
            <p><b>Email:</b> {order.shippingDetails.email}</p>
            <p><b>Phone:</b> {order.shippingDetails.phone}</p>
            <p><b>Address:</b> {order.shippingDetails.address}, {order.shippingDetails.city}, {order.shippingDetails.state} - {order.shippingDetails.zip}</p>
          </div>

          <p className="mt-2"><b>Products:</b></p>
          <ul className="list-disc pl-6">
            {order.products.map((p, i) => (
              <li key={i}>
                {p.title} x {p.quantity} = ₹{p.price * p.quantity}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  )}
</div>

  );
}

export default Orders;
