import React, { useState, useContext } from "react";
import { OrderContext } from "./OrderContext";

function Cart({ cart, setCart }) {    
  const { setOrders } = useContext(OrderContext);   // 👈 OrderContext use kiya
  const [showCheckout, setShowCheckout] = useState(false);
  const [checkoutData, setCheckoutData] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    paymentMethod: "cod",
  });

  // ✅ Input handle function
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCheckoutData((prev) => ({ ...prev, [name]: value }));
  };

  // ✅ Place order
  const handleOrder = async () => {
    try {
      const orderData = {
        userId: "123",
        products: cart.map((item) => ({
          productId: item._id || item.id,
          title: item.title,
          price: item.price,
          quantity: item.quantity || 1,
        })),
        totalAmount: totalPrice,
        ...checkoutData,
      };

      console.log("Final OrderData:", orderData);

      const res = await fetch("http://localhost:5000/order/place", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      });

      const data = await res.json();
      console.log("Order Response:", data);

      // ✅ OrderContext update
      setOrders((prev) => [...prev, orderData]);

      alert("Order placed successfully!");
      setShowCheckout(false);
      setCart([]);
      localStorage.removeItem("cart");
    } catch (err) {
      console.error("Order Error:", err);
    }
  };

  // Clear entire cart
  const clearCart = async () => {
    try {
      await fetch("http://localhost:5000/cart/clear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "123" }),
      });
      setCart([]);
      localStorage.removeItem("cart");
    } catch (err) {
      console.error(err);
    }
  };

  // Increase quantity
  const increaseQty = (idx) => {
    const newCart = [...cart];
    newCart[idx].quantity += 1;
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  // Decrease quantity
  const decreaseQty = (idx) => {
    const newCart = [...cart];
    if (newCart[idx].quantity > 1) newCart[idx].quantity -= 1;
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  // Remove item
  const removeItem = async (idx) => {
    const productId = cart[idx].id;
    try {
      await fetch("http://localhost:5000/cart/remove", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "123", productId }),
      });
      const newCart = [...cart];
      newCart.splice(idx, 1);
      setCart(newCart);
      localStorage.setItem("cart", JSON.stringify(newCart));
    } catch (err) {
      console.error(err);
    }
  };

  const totalPrice = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>

      {cart.length === 0 ? (
        <p className="text-gray-500">Cart is empty</p>
      ) : (
        <div className="space-y-6">
          {cart.map((item, idx) => (
            <div
              key={idx}
              className="flex flex-col md:flex-row items-center gap-4 border rounded-lg p-4 shadow-sm"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-24 h-24 object-cover rounded"
              />
              <div className="flex-1">
                <p className="font-medium text-lg">{item.title}</p>
                <p className="text-gray-500 text-sm line-clamp-2">
                  {item.description}
                </p>
                <div className="flex items-center gap-2 mt-2">
                  <button
                    onClick={() => decreaseQty(idx)}
                    className="border px-2 rounded"
                  >
                    -
                  </button>
                  <span>{item.quantity}</span>
                  <button
                    onClick={() => increaseQty(idx)}
                    className="border px-2 rounded"
                  >
                    +
                  </button>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <p className="font-semibold text-indigo-600 text-lg">
                  ₹{item.price * item.quantity}
                </p>
                <button
                  onClick={() => removeItem(idx)}
                  className="text-red-500 hover:underline text-sm"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          <div className="flex justify-between mt-6 text-xl font-bold">
            <span>Total: ₹{totalPrice}</span>
            <div className="flex gap-2">
              <button
                onClick={clearCart}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              >
                Clear Cart
              </button>
              <button
                onClick={() => setShowCheckout(true)}
                className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
              >
                Buy Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-lg p-6 relative">
            <h2 className="text-2xl font-bold mb-4">Checkout Details</h2>
            <button
              onClick={() => setShowCheckout(false)}
              className="absolute top-2 right-2 text-gray-500 hover:text-gray-800 font-bold"
            >
              X
            </button>

            <div className="space-y-3">
              <input
                type="text"
                name="fullName"
                placeholder="Full Name"
                value={checkoutData.fullName}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={checkoutData.email}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              />
              <input
                type="tel"
                name="phone"
                placeholder="Phone Number"
                value={checkoutData.phone}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              />
              <textarea
                name="address"
                placeholder="Address"
                value={checkoutData.address}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  name="city"
                  placeholder="City"
                  value={checkoutData.city}
                  onChange={handleChange}
                  className="flex-1 border px-3 py-2 rounded"
                />
                <input
                  type="text"
                  name="state"
                  placeholder="State"
                  value={checkoutData.state}
                  onChange={handleChange}
                  className="flex-1 border px-3 py-2 rounded"
                />
              </div>
              <input
                type="text"
                name="zip"
                placeholder="Zip Code"
                value={checkoutData.zip}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              />

              <select
                name="paymentMethod"
                value={checkoutData.paymentMethod}
                onChange={handleChange}
                className="w-full border px-3 py-2 rounded"
              >
                <option value="cod">Cash on Delivery</option>
                <option value="online">Online Payment</option>
              </select>

              <button
                onClick={handleOrder}
                className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mt-3"
              >
                Place Order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cart;
