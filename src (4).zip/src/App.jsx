// App.jsx
import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Register from "./Register";
import Home from "./Home";
import ProductDetails from "./ProductDetails";
import Cart from "./Cart";
import Orders from "./Orders"; 
import { OrderProvider } from "./OrderContext"; 

function App() {
  // Safe localStorage parsing for cart
  const [cart, setCart] = useState(() => {
    let savedCart;
    try {
      savedCart = localStorage.getItem("cart");
      return savedCart && savedCart !== "undefined"
        ? JSON.parse(savedCart)
        : [];
    } catch (err) {
      console.error("Failed to parse cart from localStorage:", err);
      return [];
    }
  });

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  return (
    <OrderProvider>
      <Routes>
        <Route path="/" element={<Register />} />
        <Route path="/home" element={<Home cart={cart} setCart={setCart} />} />
        <Route
          path="/product/:id"
          element={<ProductDetails cart={cart} setCart={setCart} />}
        />
        <Route path="/cart" element={<Cart cart={cart} setCart={setCart} />} />
        <Route path="/orders" element={<Orders />} /> {/* 👈 Orders page */}
      </Routes>
    </OrderProvider>
  );
}

export default App;
