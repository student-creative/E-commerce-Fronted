import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Navbar from "./Navbar";

function ProductDetails({ cart, setCart }) {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/product/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data))
      .catch((err) => console.error(err));
  }, [id]);

  if (!product) return <p className="p-6">Loading...</p>;


  const handleAddToCart = async (product) => {
  try {
    const res = await fetch("http://localhost:5000/cart/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: "123",
        productId: product.id,  // numeric id
        title: product.title,
        price: product.price,
        description: product.description,
        image: product.image,
        quantity: 1
      }),
    });

    const data = await res.json();
    console.log("Cart API Response:", data);

    // Ensure cart state gets products array with quantity
    setCart(data.cart.products.map(p => ({
      id: p.productId, // ya p._id depending on backend
      title: p.title,
      price: p.price,
      description: p.description,
      image: p.image,
      quantity: p.quantity
    })));
  } catch (err) {
    console.error("Error adding to cart:", err);
  }
};


  return (
    <div>
      <Navbar cart={cart} />
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left Side - Product Image */}
          <div className="md:w-1/2 flex justify-center items-start">
            <img
              src={product.image}
              alt={product.title}
              className="w-full max-w-md h-auto object-cover rounded-lg shadow-lg"
            />
          </div>

          {/* Right Side - Product Details */}
          <div className="md:w-1/2 flex flex-col gap-4">
            <h1 className="text-3xl font-bold">{product.title}</h1>
            <p className="text-gray-600">{product.description}</p>
            <p className="text-xl font-semibold text-blue-600">₹{product.price}</p>

            {/* Quantity Selector */}
            <div className="flex items-center gap-4 mt-4">
              <span className="font-medium">Quantity:</span>
              <input
                type="number"
                defaultValue={1}
                min={1}
                className="w-20 border rounded p-2"
              />
            </div>

            {/* Add to Cart Button */}
            <button  onClick={() => handleAddToCart(product)}
              className="mt-6 bg-blue-500 hover:bg-blue-600 text-white p-3 rounded font-semibold transition"
             
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
