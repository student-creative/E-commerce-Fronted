import React, { useState ,useEffect } from 'react';
import { Routes,Router, Route } from "react-router-dom";
import Register from './Register';
import Home from './Home';
import ProductDetails from './ProductDetails';
import Cart from './Cart';


function App() {
  // const [cart, setCart] = useState([]); // global cart state

    const [cart, setCart] = useState(() => {
    const savedCart = localStorage.getItem("cart");
    return savedCart ? JSON.parse(savedCart) : [];
  });

   useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  return (
    <div>
      
      <Routes>
        <Route path="/" element={<Register />} />
        <Route path="/home" element={<Home cart={cart} setCart={setCart} />} />
        <Route path="/product/:id" element={<ProductDetails cart={cart} setCart={setCart}/>} />
        <Route path="/cart" element={<Cart cart={cart} setCart={setCart} />} /> {/* Cart route */}
      
      </Routes>
     
    </div>
  )
}

export default App;
