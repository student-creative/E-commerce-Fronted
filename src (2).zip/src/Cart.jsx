import React from "react";

function Cart({ cart, setCart }) {
  // Increase quantity
  const increaseQty = (index) => {
    const newCart = [...cart];
    newCart[index].quantity += 1;
    setCart(newCart);
  };

  // Decrease quantity
  const decreaseQty = (index) => {
    const newCart = [...cart];
    if (newCart[index].quantity > 1) {
      newCart[index].quantity -= 1;
      setCart(newCart);
    }
  };

  // Remove item
  const removeItem = (index) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  // Total price
  const totalPrice = cart.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>

      {cart.length === 0 ? (
        <p className="text-gray-500">Cart is empty</p>
      ) : (
        <div className="space-y-6">
          {cart.map((item, idx) => (
            <div
              key={idx}
              className="flex flex-col md:flex-row items-center gap-4 border rounded-lg p-4 shadow-sm"
            >
              {/* Image */}
              <img
                src={item.product.image}
                alt={item.product.title}
                className="w-24 h-24 object-cover rounded"
              />

              {/* Product Details */}
              <div className="flex-1">
                <p className="font-medium text-lg">{item.product.title}</p>
                <p className="text-gray-500 text-sm line-clamp-2">
                  {item.product.description}
                </p>

                {/* Quantity Selector */}
                <div className="flex items-center gap-2 mt-2">
                  <button
                    onClick={() => decreaseQty(idx)}
                    className="border px-2 rounded"
                  >
                    -
                  </button>
                  <span>{item.quantity}</span>
                  <button
                    onClick={() => increaseQty(idx)}
                    className="border px-2 rounded"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Price & Remove */}
              <div className="flex flex-col items-end gap-2">
                <p className="font-semibold text-indigo-600 text-lg">
                  ₹{item.product.price * item.quantity}
                </p>
                <button
                  onClick={() => removeItem(idx)}
                  className="text-red-500 hover:underline text-sm"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          {/* Total */}
          <div className="flex justify-end mt-6 text-xl font-bold">
            Total: ₹{totalPrice}
          </div>
        </div>
      )}
    </div>
  );
}

export default Cart;
