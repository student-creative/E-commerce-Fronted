import { useEffect, useState } from "react";
import React from 'react'
import Navbar from './Navbar'
 import { Link } from "react-router-dom";

function Home() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/product")
      .then(res => res.json())
      .then(data => {
        console.log("API Response:", data); // check karne ke liye
        setProducts(data); // yaha state update karo
      })
      .catch(err => console.error("Error fetching products:", err));
  }, []);

  return (
    <>
      <Navbar />

      <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      

{products.map((product) => (
  <div key={product.id} className="bg-white shadow-lg rounded-lg p-4 flex flex-col">
    <Link to={`/product/${product.id}`}>
      <img src={product.image} alt={product.title} className="h-48 w-full object-cover rounded" />
      <h2 className="mt-4 font-bold text-lg">{product.title}</h2>
    </Link>
    <p className="text-gray-600 mt-2 text-sm">{product.description}</p>
    <p className="mt-2 font-semibold text-blue-600">₹{product.price}</p>
    <button className="mt-auto bg-blue-500 hover:bg-blue-600 text-white p-2 rounded mt-4">
      Add to Cart
    </button>
  </div>
))}

      </div>
    </>
  );
}

export default Home;
