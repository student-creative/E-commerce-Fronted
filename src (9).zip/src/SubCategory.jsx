import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Navbar from "./Navbar";

export default function SubCategory({ cart, setCart }) {
  const { categoryId, productId } = useParams();
  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);

  // Fetch single product
  useEffect(() => {
    fetch(`http://localhost:5000/category/${categoryId}/${productId}`)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
      })
      .then(data => setProduct(data))
      .catch(err => console.error("Fetch error:", err));
  }, [categoryId, productId]);

  // Fetch related products
  useEffect(() => {
    if (categoryId && product) {
      fetch(`http://localhost:5000/category/${categoryId}`)
        .then(res => {
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
          return res.json();
        })
        .then(data => {
          setRelated(data.products.filter(p => p._id !== product._id));
        })
        .catch(err => console.error("Fetch error:", err));
    }
  }, [categoryId, product]);

  if (!product) return <p className="text-center mt-10">Loading...</p>;

  // ✅ Add to Cart

 const handleAddToCart = async (product) => {
    try {
      const res =   await fetch("http://localhost:5000/cart/add",  {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "123",
          productId: product.id,
          title: product.title,
          price: product.price,
          description: product.description,
          image: product.image,
          quantity: 1,
        }),
      });

      const data = await res.json();
      setCart(
        data.cart.products.map((p) => ({
          id: p.productId,
          title: p.title,
          price: p.price,
          description: p.description,
          image: p.image,
          quantity: p.quantity,
        }))
      );
    } catch (err) {
      console.error("Error adding to cart:", err);
    }
  };



  return (

    
    <div className="p-6">

       <Navbar cart={cart} />
      {/* Product Detail */}
      <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-stretch mb-12">
        
        {/* Left: Image inside rectangular card */}
        <div className="border rounded-lg shadow p-6 bg-white flex justify-center items-center">
          <img
            src={product.image}
            alt={product.title}
            className="w-full h-96 object-contain"
          />
        </div>

        {/* Right: Details (centered horizontally, bottom aligned) */}
        <div className="flex flex-col justify-end text-center">
          <h2 className="text-3xl font-bold mb-3">{product.title}</h2>
          <p className="text-gray-700 mb-4">{product.description}</p>
          <p className="text-blue-600 font-bold text-2xl mb-6">₹{product.price}</p>

          <div className="flex justify-center">
            <button 
              onClick={() => handleAddToCart(product)} // ✅ button connected
              className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-2 rounded-lg font-semibold shadow-md transition w-40"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {related.length > 0 && (
        <div className="max-w-6xl mx-auto">
          <h3 className="text-2xl font-semibold mb-4">Related Products</h3>
          <div className="grid md:grid-cols-4 sm:grid-cols-2 gap-6">
            {related.map(p => (
              <div key={p._id} className="border rounded-lg shadow hover:shadow-lg transition p-4 cursor-pointer bg-white h-full">
                <img
                  src={p.image}
                  alt={p.title}
                  className="w-full h-40 object-contain rounded mb-2"
                />
                <h4 className="font-semibold mb-1">{p.title}</h4>
                <p className="text-blue-600 font-bold">₹{p.price}</p>
                <button 
                  onClick={() => handleAddToCart(p)} // ✅ related products me bhi add to cart
                  className="mt-2 bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-1 rounded-lg text-sm shadow-md transition w-full"
                >
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
