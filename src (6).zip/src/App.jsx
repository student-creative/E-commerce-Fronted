// App.jsx
import React, { useState, useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import Register from "./Register";
import Home from "./Home";
import ProductDetails from "./ProductDetails";
import Cart from "./Cart";
import Orders from "./Orders"; 
import { OrderProvider } from "./OrderContext"; 
import Payment from "./Payment";
import Category from "./Category";
import CategoryDetail from "./CategoryDetail";
import Offer from "./Offer";
import SubCategory from "./SubCategory";


function App() {
  // Safe localStorage parsing for cart
  const [cart, setCart] = useState(() => {
    let savedCart;
    try {
      savedCart = localStorage.getItem("cart");
      return savedCart && savedCart !== "undefined"
        ? JSON.parse(savedCart)
        : [];
    } catch (err) {
      console.error("Failed to parse cart from localStorage:", err);
      return [];
    }
  });

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  return (
    <OrderProvider>
      <Routes>
        <Route path="/" element={<Register />} />
        <Route path="/home" element={<Home cart={cart} setCart={setCart} />} />
        <Route
          path="/product/:id"
          element={<ProductDetails cart={cart} setCart={setCart} />}
        />
        <Route path="/cart" element={<Cart cart={cart} setCart={setCart} />} />
        <Route path="/orders" element={<Orders />} /> {/* 👈 Orders page */}
       <Route path="/payment" element={<Payment />} />
          <Route path="/category" element={<Category />} />
        <Route path="/category/:id" element={<CategoryDetail />} />
          <Route path="/offer" element={<Offer />} />
<Route path="/subcategory/:categoryId/:productId" element={<SubCategory  cart={cart} setCart={setCart} />} />




        

      </Routes>
    </OrderProvider>
  );
}

export default App;
