// Navbar.jsx
import React, { useState } from "react";
import { ShoppingCartIcon, Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { Link, useNavigate } from "react-router-dom";
export default function Navbar({ cart = [] }) {
  const [menuOpen, setMenuOpen] = useState(false);
 const navigate = useNavigate();
  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Left: Logo */}
          <div className="flex-shrink-0 text-2xl font-bold text-indigo-600">
            ShopEase
          </div>

          {/* Center: Search Bar (hidden on small screens) */}
          <div className="hidden md:block flex-1 px-4">
            <input
              type="text"
              placeholder="Search products..."
              className="w-full px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-indigo-400 outline-none"
            />
          </div>

          {/* Right: Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/home" className="text-gray-700 hover:text-indigo-600">Shop</Link>
            <Link to="" className="text-gray-700 hover:text-indigo-600">Categories</Link>
            <Link to="" className="text-gray-700 hover:text-indigo-600">Offers</Link>
            <Link to="" className="text-gray-700 hover:text-indigo-600">Contact</Link>

            {/* Cart */}
             <div
      className="relative cursor-pointer"
      onClick={() => navigate("/Cart")} // click par Cart.jsx open
    >
      <ShoppingCartIcon className="h-6 w-6 text-gray-700" />
      {cart.length > 0 && (
        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
          {cart.length}
        </span>
      )}
    </div>

            {/* Login & Signup */}
            <button  onClick={() => navigate("/")} className="px-4 py-1 border border-indigo-600 text-indigo-600 rounded-full hover:bg-indigo-600 hover:text-white transition">Login</button>
            <button  onClick={() => navigate("/")} className="px-4 py-1 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition">
              Signup
            </button>
          </div>

          {/* Mobile Hamburger */}
          <div className="md:hidden">
            <button onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? (
                <XMarkIcon className="h-6 w-6 text-gray-700" />
              ) : (
                <Bars3Icon className="h-6 w-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-4 py-2 space-y-2">
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Shop</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Categories</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Offers</a>
            <a href="#" className="block text-gray-700 hover:text-indigo-600">Contact</a>

            {/* Cart */}
            <div className="flex items-center space-x-2">
              <ShoppingCartIcon className="h-6 w-6 text-gray-700" />
              <span className="text-gray-700">Cart (3)</span>
            </div>

            {/* Auth Buttons */}
            <button className="w-full px-4 py-2 border border-indigo-600 text-indigo-600 rounded-full hover:bg-indigo-600 hover:text-white transition">
              Login
            </button>
            <button className="w-full px-4 py-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition">
              Signup
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
