import React from "react";

function Cart({ cart, setCart }) {
   
  
  // Clear entire cart
  const clearCart = async () => {
    try {
      await fetch("http://localhost:5000/cart/clear", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "123" }),
      });

      setCart([]);                 // React state clear
      localStorage.removeItem("cart"); // localStorage clear
    } catch (err) {
      console.error(err);
    }
  };

  // Increase quantity (frontend only for now)
  const increaseQty = (idx) => {
    const newCart = [...cart];
    newCart[idx].quantity += 1;
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  };

  // Decrease quantity (frontend only for now)
  const decreaseQty = (idx) => {
    const newCart = [...cart];
    if (newCart[idx].quantity > 1) {
      newCart[idx].quantity -= 1;
      setCart(newCart);
      localStorage.setItem("cart", JSON.stringify(newCart));
    }
  };
const removeItem = async (idx) => {

    
const productId = cart[idx].id; // 👈 ab productId bhejo

  console.log("🟢 Removing product:", productId);
  try {
    await fetch("http://localhost:5000/cart/remove", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: "123", productId }), // body check karna
    });

    const newCart = [...cart];
    newCart.splice(idx, 1);
    setCart(newCart);
    localStorage.setItem("cart", JSON.stringify(newCart));
  } catch (err) {
    console.error(err);
  }
};



  // Total price
  const totalPrice = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>

      {cart.length === 0 ? (
        <p className="text-gray-500">Cart is empty</p>
      ) : (
        <div className="space-y-6">
          {cart.map((item, idx) => (
            <div key={idx} className="flex flex-col md:flex-row items-center gap-4 border rounded-lg p-4 shadow-sm">
              <img src={item.image} alt={item.title} className="w-24 h-24 object-cover rounded" />
              <div className="flex-1">
                <p className="font-medium text-lg">{item.title}</p>
                <p className="text-gray-500 text-sm line-clamp-2">{item.description}</p>
                <div className="flex items-center gap-2 mt-2">
                  <button onClick={() => decreaseQty(idx)} className="border px-2 rounded">-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => increaseQty(idx)} className="border px-2 rounded">+</button>
                </div>
              </div>
              <div className="flex flex-col items-end gap-2">
                <p className="font-semibold text-indigo-600 text-lg">₹{item.price * item.quantity}</p>
                <button onClick={() => removeItem(idx)} className="text-red-500 hover:underline text-sm">Remove</button>
              </div>
            </div>
          ))}

          {/* Total & Clear */}
          <div className="flex justify-between mt-6 text-xl font-bold">
            <span>Total: ₹{totalPrice}</span>
            <button onClick={clearCart} className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">
              Clear Cart
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Cart;
