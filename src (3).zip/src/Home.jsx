import { useEffect, useState } from "react";
import React from 'react'
import Navbar from './Navbar'
import { Link } from "react-router-dom";

function Home({ cart, setCart }) {
  const [products, setProducts] = useState([]);


  

  // Fetch Products
useEffect(() => {
  fetch("http://localhost:5000/product/api") // /api/product
    .then(res => res.json())
    .then(data => {
      console.log("API Response:", data); 
      setProducts(data); // products state me array save
    })
    .catch(err => console.error("Error fetching products:", err));
}, []);


  // Fetch Cart from API

const handleAddToCart = async (product) => {
  try {
    const res = await fetch("http://localhost:5000/cart/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: "123",
        productId: product.id,  // numeric id
        title: product.title,
        price: product.price,
        description: product.description,
        image: product.image,
        quantity: 1
      }),
    });

    const data = await res.json();
    console.log("Cart API Response:", data);

    // Ensure cart state gets products array with quantity
    setCart(data.cart.products.map(p => ({
      id: p.productId, // ya p._id depending on backend
      title: p.title,
      price: p.price,
      description: p.description,
      image: p.image,
      quantity: p.quantity
    })));
  } catch (err) {
    console.error("Error adding to cart:", err);
  }
};






  return (
    <>
      {/* Navbar ko cart state pass kiya */}
      <Navbar cart={cart} />

      <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="bg-white shadow-lg rounded-lg p-4 flex flex-col">
            <Link to={`/product/${product.id}`}>
              <img src={product.image} alt={product.title} className="h-48 w-full object-cover rounded" />
              <h2 className="mt-4 font-bold text-lg">{product.title}</h2>
            </Link>
            <p className="text-gray-600 mt-2 text-sm">{product.description}</p>
            <p className="mt-2 font-semibold text-blue-600">₹{product.price}</p>
            <button 
              onClick={() => handleAddToCart(product)}
              className="mt-auto bg-blue-500 hover:bg-blue-600 text-white p-2 rounded mt-4"
            >
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </>
  );
}

export default Home;
