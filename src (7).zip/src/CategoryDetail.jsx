import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navbar from "./Navbar";

export default function CategoryDetail() {
  const { id } = useParams(); // categoryId
  const [category, setCategory] = useState(null);
  const navigate = useNavigate();

  // Fetch category with products
  useEffect(() => {
    fetch(`http://localhost:5000/category/${id}`)
      .then(res => {
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        return res.json();
      })
      .then(data => setCategory(data))
      .catch(err => console.error("Fetch error:", err));
  }, [id]);

  if (!category) return <p className="text-center mt-10">Loading...</p>;

  // Navigate to SubCategory/Product Detail
  const handleProductClick = (productId) => {
    navigate(`/subcategory/${id}/${productId}`);
  };

  return (
    <div>
      <Navbar/>
    <div className="p-6">
      <h2 className="text-3xl font-bold mb-6 text-center">{category.name}</h2>
      <p className="text-center text-gray-600 mb-8">{category.description}</p>

      <div className="grid md:grid-cols-3 sm:grid-cols-2 gap-6">
        {category.products?.length > 0 ? (
          category.products.map((p) => (
            <div
              key={p._id}
              onClick={() => handleProductClick(p._id)}
              className="border rounded-lg overflow-hidden shadow hover:shadow-xl transition-shadow bg-white cursor-pointer"
            >
              <img src={p.image} alt={p.title} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h3 className="font-semibold text-lg">{p.title}</h3>
                <p className="text-gray-600 mt-1">{p.description}</p>
                <p className="text-blue-600 font-bold mt-2">₹{p.price}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 col-span-full">No products available.</p>
        )}
      </div>
    </div>
        </div>
  );
}
