import React, { useContext, useEffect, useState } from "react";
import { OrderContext } from "./OrderContext";

function Orders() {
  const { orders, setOrders } = useContext(OrderContext);
  const [loading, setLoading] = useState(false);
  const userId = "123"; // Replace with logged-in user's ID

  // Fetch orders
  useEffect(() => {
    setLoading(true);
    fetch(`http://localhost:5000/order/${userId}`)
      .then((res) => res.json())
      .then((data) => {
        setOrders(data.orders || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Fetch error:", err);
        setLoading(false);
      });
  }, [userId]);

  // Cancel order
  const handleCancel = async (orderId) => {
    if (!window.confirm("Are you sure you want to cancel this order?")) return;

    try {
      const res = await fetch(`http://localhost:5000/order/${orderId}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (res.ok) {
        alert("Order cancelled successfully!");
        // Update orders state
        setOrders(orders.filter((o) => o._id !== orderId));
      } else {
        alert(data.message || "Failed to cancel order");
      }
    } catch (err) {
      console.error(err);
      alert("Something went wrong");
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">My Orders</h1>

      {loading ? (
        <p className="text-gray-500">Loading orders...</p>
      ) : orders.length === 0 ? (
        <p className="text-gray-500">No orders placed yet.</p>
      ) : (
        <div className="space-y-6">
          {orders.map((order, idx) => (
            <div
              key={idx}
              className="border rounded-xl shadow-lg p-6 bg-white hover:shadow-2xl transition-shadow duration-300"
            >
              <div className="flex justify-between items-center">
                <h2 className="font-semibold text-lg text-gray-700">
                  Order ID: {order._id}
                </h2>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    order.status === "Pending"
                      ? "bg-yellow-100 text-yellow-800"
                      : order.status === "Delivered"
                      ? "bg-green-100 text-green-800"
                      : "bg-red-100 text-red-800"
                  }`}
                >
                  {order.status}
                </span>
              </div>

              <p className="mt-2 text-gray-600">
                <b>Total:</b> ₹{order.totalAmount} &nbsp;|&nbsp;{" "}
                <b>Date:</b> {new Date(order.createdAt).toLocaleString()}
              </p>

              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <h3 className="font-semibold text-gray-700 mb-2">Shipping Details</h3>
                <p><b>Name:</b> {order.shippingDetails.fullName}</p>
                <p><b>Email:</b> {order.shippingDetails.email}</p>
                <p><b>Phone:</b> {order.shippingDetails.phone}</p>
                <p>
                  <b>Address:</b> {order.shippingDetails.address}, {order.shippingDetails.city},{" "}
                  {order.shippingDetails.state} - {order.shippingDetails.zip}
                </p>
                <p><b>Payment:</b> {order.shippingDetails.paymentMethod}</p>
              </div>

              <div className="mt-4">
                <p className="font-semibold text-gray-700">Products:</p>
                <ul className="list-disc pl-6 mt-2 text-gray-600">
                  {order.products.map((p, i) => (
                    <li key={i}>
                      {p.title} x {p.quantity} = ₹{p.price * p.quantity}
                    </li>
                  ))}
                </ul>
              </div>

            
                <div className="mt-4 text-right">
                  <button
                    onClick={() => handleCancel(order._id)}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
                  >
                    Cancel Order
                  </button>
                </div>
             
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Orders;
