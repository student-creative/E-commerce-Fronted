import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeftIcon } from "@heroicons/react/24/solid"; // ✅ Heroicons import
import Navbar from "./Navbar";

function ProductDetails({ cart, setCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  useEffect(() => {
    // Fetch main product
    fetch(`http://localhost:5000/product/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data))
      .catch((err) => console.error(err));

    // Fetch suggested products
    fetch(`http://localhost:5000/product/suggestions/${id}`)
      .then((res) => res.json())
      .then((data) => setSuggestions(data))
      .catch((err) => console.error(err));
  }, [id]);

  if (!product) return <p className="p-6">Loading...</p>;

  const handleAddToCart = async (product) => {
    try {
      const res = await fetch("http://localhost:5000/cart/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "123",
          productId: product.id,
          title: product.title,
          price: product.price,
          description: product.description,
          image: product.image,
          quantity: 1,
        }),
      });

      const data = await res.json();
      setCart(
        data.cart.products.map((p) => ({
          id: p.productId,
          title: p.title,
          price: p.price,
          description: p.description,
          image: p.image,
          quantity: p.quantity,
        }))
      );
    } catch (err) {
      console.error("Error adding to cart:", err);
    }
  };

  return (
    <div>
      <Navbar cart={cart} />

      <div className="p-6 max-w-6xl mx-auto">
        {/* ✅ Back Button with Icon */}
        <div className="mb-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md shadow-md"
          >
            <ArrowLeftIcon className="w-5 h-5" />
            Back
          </button>
        </div>

        {/* Main Product Section */}
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left side product image */}
          <div className="md:w-1/3 flex justify-center items-start">
            <div className="border rounded-lg p-4 bg-white shadow">
              <img
                src={product.image}
                alt={product.title}
                className="w-full h-80 object-contain"
              />
            </div>
          </div>

          {/* Right side product details */}
          <div className="md:w-2/3 flex flex-col gap-4">
            <h1 className="text-3xl font-bold">{product.title}</h1>
            <p className="text-gray-600">{product.description}</p>
            <p className="text-2xl font-semibold text-green-600">₹{product.price}</p>

            <div className="flex items-center gap-4 mt-2">
              <span className="font-medium">Quantity:</span>
              <input
                type="number"
                defaultValue={1}
                min={1}
                className="w-20 border rounded p-2"
              />
            </div>

            {/* Chhota stylish Add to Cart button */}
            <button
              onClick={() => handleAddToCart(product)}
              className="mt-4 px-5 py-2 bg-yellow-500 hover:bg-yellow-600 text-black text-sm font-semibold rounded-lg shadow-md transition"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>

      {/* Suggested Products Section */}
      {suggestions.length > 0 && (
        <div className="max-w-6xl mx-auto p-6 mt-12">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">
            You may also like
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
            {suggestions.map((item) => (
              <div
                key={item.id}
                className="border rounded-lg shadow hover:shadow-lg transition p-4 flex flex-col items-center"
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-40 object-contain rounded-lg mb-2"
                />
                <h3 className="text-sm font-semibold text-gray-700 mb-1 text-center">
                  {item.title.length > 30
                    ? item.title.substring(0, 30) + "..."
                    : item.title}
                </h3>
                <p className="text-green-600 font-semibold mb-2">₹{item.price}</p>
                <button
                  onClick={() => handleAddToCart(item)}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black text-xs px-3 py-1.5 rounded transition shadow"
                >
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default ProductDetails;
