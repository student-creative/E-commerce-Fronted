import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Category() {
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost:5000/category")
      .then((res) => res.json())
      .then((data) => setCategories(data.categories))
      .catch((err) => console.error(err));
  }, []);

  const handleCategoryClick = (cat) => {
    navigate(`/category/${cat._id}`);
  };

  return (
    <div className="bg-gradient-to-br from-gray-50 to-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl font-extrabold mb-12 text-center bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent drop-shadow-lg">
          Shop by Categories
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {categories.map((cat) => (
            <div
            
              className="group relative cursor-pointer rounded-lg overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 bg-white flex flex-col"
              style={{ minHeight: "350px" }}
            >
              {/* Category Image - Rectangle */}
              {/* Category Image - Rectangle */}
<div className="w-full h-56 overflow-hidden"> 
  <img
    src={cat.image}
    alt={cat.name}
    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
  />
</div>


              {/* Info Box */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-lg md:text-xl text-gray-800 group-hover:text-purple-600 transition-colors duration-300">
                    {cat.name}
                  </h3>
                  <p className="text-sm text-gray-600 mt-2 line-clamp-3">
                    {cat.description}
                  </p>
                </div>
                <button   key={cat._id}
              onClick={() => handleCategoryClick(cat)} className="mt-4 w-full py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
                  Shop Now
                </button>
              </div>

            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
